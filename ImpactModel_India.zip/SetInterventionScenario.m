function [p1,r1]=SetInterventionScenario(p,r,xs,IntvVec)

%r_cs:           Rate-of-presentation to care, first careseeking visit for symptomatic TB
%r_cs2:          Rate-of-presentation to care, second and subsequent careseeking visits for symptomatic TB
%r.cs3:          Per-capita rate of casefinding amongst sub-clinical TB
%p_pu:           Proportion of careseeking visits that are to the public sector
%p_Dx            Probability of successful TB diagnosis and treatment initiation per careseeking visit (in public and private sector)
%r_progression:	 Per-capita annual rate of progression from �fast� latent infection (differentiated by HIV-status, h0, h1, hart)
%r_reactivation: Per-capita annual rate of reactivation from �slow� latent infection  (differentiated by HIV-status, h0, h1, hart)
%r_Tx2:          Per-capita annual rate of second-tline treatment completion
%p_cure2:        Proportion cure after successful completion of SL treatment 
%p_TX_complete:  Proportion treatment completion (used to estimate per-capita annual rate of treatment interruption (r.default) in public and private sector)
%p_MDRrec2019:	 Of diagnosed TB with rifampcin resistance, proportion that is recognised as such in 2019 (throgh DST)
%r_relapse(1):	 Per-capita annual rate of relapse in first two years after treatment completion
%r_relapse(2):	 Per-capita annual rate of relapse in first two years after self-cure or incomplete treatment
%r_relapse(3)	 Per-capita annual rate of relapse >two years after last TB episode
%p_VE(1):        Vaccine efficacy on reduction of susceptibility (pre-exposure protection)
%p_VE(2):        Vaccine efficacy on reduction of progression to active disease (post-exposure protection)
%r_vacc:         Per-capita annual rate of vaccination
%r_waning:       Per-capita annual rate of waning vaccine immunity


%copy model parameters
p1=p;
r1=r;

fn = fieldnames(IntvVec);
for k=1:numel(fn)
     if( ~isempty(IntvVec.(fn{k})) )
          if( strcmp(fn{k},'r_cs') ),
              factor=IntvVec.(fn{k});
              if(sum(factor)==0),
                  r1.pu=0;
                  %r1.ART_init = 0; 
                  %p1.MDR_rec = [0 0]; 
              end
              for J=1:length(factor)  
                if(factor(J)>1)  
                    r1.cs(J)=r1.cs(J)*factor(J);
                elseif (factor(J)<1)
                   r1.cs(J)  = r1.cs_1997(J) + factor(J)*(r1.cs(J)-r1.cs_1997(J));
                   %r1.pu     = r1.pu*factor(1);
                end
                
              end
              %r1.cs=r1.cs.*IntvVec.(fn{k});
          end
          
          if( strcmp(fn{k},'r_cs2') ),
              factor=IntvVec.(fn{k});
              if(sum(factor)==0),
                  r1.pu=0;
                  %r1.ART_init = 0; 
                  %p1.MDR_rec = [0 0];
              end
              for J=1:length(factor)
                if(factor(J)>1)  
                    r1.cs2(J)=r1.cs2(J)*factor(J);
                elseif (factor(J)<1)
                    r1.cs2(J)  = r1.cs2_1997(J) + factor(J)*(r1.cs2(J)-r1.cs2_1997(J)); 
                end
                
              end
              %r1.cs2=r1.cs2.*IntvVec.(fn{k});
          end
         
          if( strcmp(fn{k},'r_cs3') ),
              r1.cs3=r1.cs3.*IntvVec.(fn{k});
          end
          
          if( strcmp(fn{k},'p_pu') ),
              p1.pu=IntvVec.(fn{k});
          end
          
          if( strcmp(fn{k},'p_Dx') ),
              p1.Dx=IntvVec.(fn{k});
          end
         
          
          if( strcmp(fn{k},'p_PT_PLHIV') ),
              p1.PT_PLHIV=(1-IntvVec.(fn{k}));
          end

          if( strcmp(fn{k},'r_progression') ),
              r1.progression=r1.progression.*(1-IntvVec.(fn{k}));
          end
          
          if( strcmp(fn{k},'r_reactivation') ),
              r1.reactivation=r1.reactivation.*(1-IntvVec.(fn{k}));
          end
          
          if( strcmp(fn{k},'r_Tx2') ),
              r1.Tx2=IntvVec.(fn{k});
          end
          
          if( strcmp(fn{k},'p_cure') ),
              %p1.cure=p1.cure*(1-IntvVec.(fn{k}));
              %p1.cure(1)=max(p1.cure(1),IntvVec.(fn{k}));
              %p1.cure=1-(1-p1.cure)*(1-IntvVec.(fn{k}));
              %r1.Tx=r1.Tx*IntvVec.(fn{k});
              
              del = max(IntvVec.(fn{k})-1,0);              % Percent increase of treatment completion. (increase in Tx success)
              p_Tx_complete(1) = min(xs(12)*(1+del),1);    % Estimated treatment completion in public sector
              %r1.default(1) = r.Tx*(1-p_Tx_complete(1))./p_Tx_complete(1);
          end
          
          if( strcmp(fn{k},'p_cure2') ),
              %p1.cure2(1)=1-(1-p1.cure2(2))*(1-IntvVec.(fn{k}));
               %r1.Tx2=r1.Tx2*IntvVec.(fn{k});
          end
          
          if( strcmp(fn{k},'r_default') ),
              r1.default(1)=r1.default(1)*(1-IntvVec.(fn{k}))^1;
              
          end
          
           if( strcmp(fn{k},'r_default2') ),
              r1.default2(1)=r1.default2(1)*(1-IntvVec.(fn{k}))^1;
          end
         
          if( strcmp(fn{k},'p_TX_complete') ),
              p1.TX_complete=IntvVec.(fn{k});
          end
          
          if( strcmp(fn{k},'p_MDRrec') ),
              p1.MDR_rec=IntvVec.(fn{k});
          end
          
          if( strcmp(fn{k},'r_relapse_1') ),
              r1.relapse(1)=IntvVec.(fn{k});
          end
          
          if( strcmp(fn{k},'r_relapse_2') ),
              r1.relapse(2)=IntvVec.(fn{k});
          end
   
          if( strcmp(fn{k},'r_relapse_3') ),
              r1.relapse(3)=IntvVec.(fn{k});
          end
          
          if( strcmp(fn{k},'p_VE_1') ),
              p1.VE(1)=IntvVec.(fn{k});
          end
          
          if( strcmp(fn{k},'p_VE_2') ),
              p1.VE(2)=IntvVec.(fn{k});
          end
          
          if( strcmp(fn{k},'r_vacc') ),
              r1.vacc=IntvVec.(fn{k});
          end
          
          if( strcmp(fn{k},'r_waning') ),
              r1.waning=IntvVec.(fn{k});
          end
          
          if( strcmp(fn{k},'r_ART_init') ),
              r1.ART_init=r1.ART_init*IntvVec.(fn{k});
          end
    
          
          
     end
end


end

 
