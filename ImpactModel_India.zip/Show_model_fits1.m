clear all;  load calibres1.mat  % 
 
load Model_setup;
% load xsto1
xsto =xsto2; 
%xsto(:,20) = 0.98;

ix0 = 2e4; nx = 150; dx = round((size(xsto,1)-ix0)/nx);
xs = xsto(ix0:dx:end,:,1);
pct_xs = prctile(xs,[2.5,50,97.5])

obj = @(x) get_objective(x, prm, ref, sel, agg, gps,gps1,gps2,lhd);
          
% inds = find(outsto==max(outsto));
% xs = xsto(inds(1),:);

mk = round(size(xs,1)/25);
for ii = 1:size(xs,1)
    if mod(ii,mk) == 0; fprintf('%0.5g ',ii/mk); end 
    [out, aux] = obj(xs(ii,:));
    %keyboard; 
    %sims(ii,:) = [aux.inc_all, aux.inc_h1, aux.noti, aux.mort_H0, aux.mort_H1, aux.ART_covg, aux.HIV_prev, aux.mdr2015, aux.mdr2022, aux.mdriniTX]; %1.64*aux.mdr2019
    sims(ii,:) = [aux.inc2000,aux.inc2022, aux.noti, aux.mort_H02022,  aux.mdr2015, aux.mdr2022, aux.mdriniTX]; %1.64*aux.mdr2019
    inct(:,:,ii) = diff(aux.soln(:,i.aux.inc),1)*1e5;   %2003:2019
   % acqu(:,:,ii) = diff(aux.soln(:,i.aux.acqu),1)*1e5;  %2003:2019
    
end
fprintf('\n');

inc_pct = permute(prctile(inct,[2.5,50,97.5],3),[3,1,2]);                  % 1. Lo/Md/Hi, 2.Time, 3.All/HIV only
%acqu_pct = permute(prctile(acqu,[2.5,50,97.5],3),[3,1,2]);                  % 1. Lo/Md/Hi, 2.Time, 3.All/HIV only

%mdr_pct = permute(prctile((inct(:,3,:)+acqu),[2.5,50,97.5],3),[3,1,2]);   % Total MDR including Acquired
mdr_pct = permute(prctile((inct(:,3,:)),[2.5,50,97.5],3),[3,1,2]);   % Total MDR including Acquired

%acqu_2019 = acqu_pct(:,end);
    
% --- Show all on a plot --------------------------------------------------

pop1997_2022 = [1001579679,1020098209,1038578378, data.pop00_22]; % 1997-1999 f=data from GTB report 2015
 
fs = 12;
pop_tot = sum(aux.soln(1:end-1,1:435),2); 
figure; plot(1997:2022,pop_tot*pop1997_2022(1)./pop_tot(1),'LineWidth',1.5); hold on
scatter(1997:2022, pop1997_2022)
ylabel('Populatopn','fontsize',14);
 
 pop_a1 = sum(aux.soln(:,s.a1),2);
 pop_a2 = sum(aux.soln(:,s.a2),2);
 pop_a3 = sum(aux.soln(:,s.a3),2);
 pop_a4 = sum(aux.soln(:,s.a4),2);
 pop_a5 = sum(aux.soln(:,s.a5),2);
 

 figure; plot(1997:2023,[pop_a1,pop_a2,pop_a3,pop_a4,pop_a5]*100,'LineWidth',1.5)
 %xticklabels([2019:4:2039]);
set(gca,'fontsize',fs);
ylabel('Percentage of populatopn','fontsize',14);
xlabel('Year','fontsize',14);
legend('0-4 year','5-9 year','10-14 year','15-64 year','65+ year','Location','NorthEast')
title('India')

%pop1997=  [pop_a1(1),pop_a2(1),pop_a3(1),pop_a4(1),pop_a5(1)]./pop_tot(1);

% Proportion of population from model
pop2022=[pop_a1(end),pop_a2(end),pop_a3(end),pop_a4(end),pop_a5(end)]./pop_tot(end)
% ppop  % Proportion of population from data


% figure; fs = 14;
%
% % --- Incidence plot
% subplot(2,2,1);
% 
% plt = inc_pct(:,:,1);  % All TB  %sum(inc_pct,3); 
% plot(plt(2,:)); hold on;
% jbfill(1:size(plt,2),plt(3,:),plt(1,:),'b','None',1,0.3); hold on;
% yl = ylim; yl(1) = 0; ylim(yl);
% 
% plt = inc_pct(:,:,2); % HIV-TB %sum(inc_pct(:,:,[2,3]),3);  
% plot(plt(2,:)); hold on;
% jbfill(1:size(plt,2),plt(3,:),plt(1,:),'r','None',1,0.3); hold on;
% yl = ylim; yl(1) = 0; ylim(yl);
% 
% ylabel('Incidence');
% set(gca,'fontsize',fs);
% 
% subplot(2,2,2)
% plt = mdr_pct; %inc_pct(:,:,3); % MDR-TB %sum(inc_pct(:,:,[2,3]),3);  
% plot(plt(2,:)); hold on;
% jbfill(1:size(plt,2),plt(3,:),plt(1,:),'r','None',1,0.3); hold on;
% yl = ylim; yl(1) = 0; ylim(yl);
% 
% ylabel('MDR Incidence');
% set(gca,'fontsize',fs);
% 
% % --- Comparing model outputs with simulations
% subplot(2,2,3); hold on;
% % Plot data
% plt  = [data.inc_all; data.inc_h1; data.noti]'; 
% hilo = diff(plt,1); md = plt(2,:);
% xpts = [1:length(plt)]-0.1;
% 
% plot(xpts, md, 'r.', 'markersize', 24);
% errorbar(xpts, md, hilo(1,:), hilo(2,:), 'LineStyle', 'None', 'Color', 'r');
% 
% % Plot simulations
% plt = prctile(sims(:,1:3),[2.5,50,97.5],1);
% hilo = diff(plt,1); md = plt(2,:);
% xpts = [1:size(hilo,2)]+0.1;
% 
% plot(xpts, md, 'b.', 'markersize', 24);
% errorbar(xpts, md, hilo(1,:), hilo(2,:), 'LineStyle', 'None', 'Color', 'b');
% xlim([0.5 3.5]);
% 
% set(gca,'fontsize',fs,'XTick',1:size(sims,2),'XTickLabel',{'Incd all', 'Incd H1', 'Noti'});
% xtickangle(45);
% 
% subplot(2,2,4); hold on;
% % Plot data
% %plt  = [data.mort_H0; data.mort_H1; data.ART_covg; data.HIV_prev; data.mdr2019; data.mdriniTX]'; 
% plt  = [data.mort_H0; data.ART_covg; data.HIV_prev; data.mdr2019; data.mdriniTX]'; 
% 
% hilo = diff(plt,1); md = plt(2,:);
% xpts = [1:length(plt)]-0.1;
% 
% plot(xpts, md, 'r.', 'markersize', 24);
% errorbar(xpts, md, hilo(1,:), hilo(2,:), 'LineStyle', 'None', 'Color', 'r');
% 
% % Plot simulations
% % Adjusting MDR adding acquired MDR
% sims(:,8)= permute((inct(end,3,:)+acqu(end,:,:)),[3,2,1]); % Adding acquired MDR in the 8th column of 'sims'
% plt = prctile(sims,[2.5,50,97.5],1);
% %hilo = diff(plt(:,4:end),1); md = plt(2,4:end);
% hilo = diff(plt(:,[4,6:end]),1); md = plt(2,[4,6:end]);
% xpts = [1:size(hilo,2)]+0.1;
% 
% plot(xpts, md, 'b.', 'markersize', 24);
% errorbar(xpts, md, hilo(1,:), hilo(2,:), 'LineStyle', 'None', 'Color', 'b');
% xlim([0.5 6.5]);
% 
% %set(gca,'fontsize',fs,'XTick',1:size(hilo,2),'XTickLabel',{'Mort H0', 'Mort H1', 'ART covg', 'HIV prev','MDR 2019','MDR Tx-initiation'});
% set(gca,'fontsize',fs,'XTick',1:size(hilo,2),'XTickLabel',{'Mort H0', 'ART covg', 'HIV prev','MDR 2019','MDR Tx-initiation'});
% xtickangle(45);









%%%%%%%%%%%%%%%%%%%%%%
figure; fs = 14;

% --- Comparing model outputs with simulations
subplot(1,2,1); hold on;
% Plot data
%plt  = [data.inc_all; data.inc_h1; data.noti; data.mort_H0]'; 
plt  = [data.inc2000; data.inc2022;  data.noti2022; data.mort_H02022]'; 
hilo = diff(plt,1); md = plt(2,:);
xpts = [1:length(plt)]-0.1;

plot(xpts, md, 'r.', 'markersize', 24);
errorbar(xpts, md, hilo(1,:), hilo(2,:), 'LineStyle', 'None', 'Color', 'r');

%  sims(ii,:) = [aux.inc_all, aux.inc_h1, aux.noti, aux.mort_H0, aux.mort_H1, aux.ART_covg, aux.HIV_prev, aux.mdr2015, aux.mdr2019, aux.mdriniTX]; %1.64*aux.mdr2019
 
% Plot simulations
plt = prctile(sims(:,1:4),[2.5,50,97.5],1);
hilo = diff(plt,1); md = plt(2,:);
xpts = [1:size(hilo,2)]+0.1;

plot(xpts, md, 'b.', 'markersize', 24);
errorbar(xpts, md, hilo(1,:), hilo(2,:), 'LineStyle', 'None', 'Color', 'b');
xlim([0.4 4.5]);
ylabel('Rate per 100,000')
title('India');
set(gca,'fontsize',fs,'XTick',1:size(sims,2),'XTickLabel',{'Incidence 2015','Incidence 2022(includes HIV+TB)', 'Notification','Mortality (excludes HIV+TB)'});
xtickangle(45);

subplot(1,2,2); hold on;
% Plot data
%plt  = [data.mort_H0; data.mort_H1; data.ART_covg; data.HIV_prev; data.mdr2019; data.mdriniTX]'; 
plt  = [data.mdr2015; data.mdr2022; data.mdriniTX]'; 

hilo = diff(plt,1); md = plt(2,:);
xpts = [1:length(plt)]-0.1;

plot(xpts, md, 'r.', 'markersize', 24);
errorbar(xpts, md, hilo(1,:), hilo(2,:), 'LineStyle', 'None', 'Color', 'r');

% Plot simulations
% Adjusting MDR adding acquired MDR
%sims(:,8)= permute((inct(end,3,:)+acqu(end,:,:)),[3,2,1]); % Adding acquired MDR in the 8th column of 'sims'
plt = prctile(sims,[2.5,50,97.5],1);
%hilo = diff(plt(:,4:end),1); md = plt(2,4:end);
hilo = diff(plt(:,[5:end]),1); md = plt(2,[5:end]);
xpts = [1:size(hilo,2)]+0.1;

plot(xpts, md, 'b.', 'markersize', 24);
errorbar(xpts, md, hilo(1,:), hilo(2,:), 'LineStyle', 'None', 'Color', 'b');
xlim([0.5 3.5]);
ylabel('Rate and proportion')
title('India');
%set(gca,'fontsize',fs,'XTick',1:size(hilo,2),'XTickLabel',{'Mort H0', 'Mort H1', 'ART covg', 'HIV prev','MDR 2019','MDR Tx-initiation'});
set(gca,'fontsize',fs,'XTick',1:size(hilo,2),'XTickLabel',{ 'MDR incidence (2015)','MDR incidence (2022)','MDR Tx-initiation'});
xtickangle(45);









%%%%%%%%%%%%%%%
% Create JSON data file 
s = struct('data',data, 'r', r, 'p',p, 'prm',prm, 'xs',xs);
jsonencode(s)

tmp = jsonencode(s);
fid = fopen('JSON_data.json', 'w');
fprintf(fid, '%s', tmp);
fclose(fid);

