clear all; %load calibres2; xsto = xsto4;
         
load calibres2; xsto = xsto3; %(2e4:end,:);

[M,I] = max(outsto3); %(2e4:end,:));

load Model_setup;

xs = xsto(I,:);  % Most probable parameter set 

ix0 = 2e4; nx = 150; dx = round((size(xsto,1)-ix0)/nx); %2e4 nx = 150
xs_all = xsto(ix0:dx:end,:,1);

pct_xs= prctile(xs_all,[2.5,50,97.5])


% % --- Get the Regional notifications
tend1   = 2024;  % Intervention starts except vaccination  
tend1b  = 2028;  % Vaccination starts
tend2   = 2035+1;  % End date for simulation

% --- Do the simulations 
opts = odeset('NonNegative',[1:i0.nstates],'Refine',64,'AbsTol',1e-10,'RelTol',1e-10);


r0 = r; p0 = p;
inct = [];
noti = [];

% mk = round(size(xs,1)/25);
% for ii = 1:size(xs,1)
%     if mod(ii,mk) == 0; fprintf('%0.5g ',ii/mk); end 
    
    [r,p] = alloc_parameters(xs,prm.r,prm.p,xi);
    % Get the initial conditions
    [out, aux] = obj(xs);
    init = aux.soln(end,1:end);

    % Extend initial condition for the full model with vaccine compartments  
    inds1 = intersect(s0.U, s0.v0);
    inds2 = intersect([s0.Lf, s0.Ls], s0.v0);
    inds3 = [s0.Isc, s0.I, s0.E, s0.Rlo, s0.Rhi, s0.R];
    inds4 = [s0.Dx,s0.Tx,s0.Tx2];
    inds5 =  s0.Tx2(end)+[1:9];  % Auxiliary terms
    ind = [inds1, inds2, inds3,inds4,inds5];
   
    % To allocate results from a model without vaccine to input vector for full model with vaccine
    init0 = zeros(1,i0.nx);
    init0(ind) = init;   

    tref = [2022:1:tend2];
   
     % --- Now simulate without intervention (baseline)
     p.pu = p.pu_2022; r.cs = r.cs_2022; r.cs2 = r.cs2_2022; p.MDR_rec = p.MDR_rec2022;
     prm.growth = prm.gth(4);
     M0 = make_model3(p, r, i0, s0, gps0, prm); 
 
  % trend=(1-((data.inc2015(2)-data.inc2022(2))/(data.inc2015(2)*(2022-2015))));
    %r.betared = 0.987; %trend; % Additional reduction of beta to capture current incidence trend.
    geq = @(t,in) goveqs_scaleup(t, in, r, M0, M0, [2022 2023], i0, prm, sel0, agg0);
    [t0, soln0] = ode15s(geq, [2022:tend2], init0, odeset('NonNegative',[1:i0.nstates]));
       
    soln  = soln0;
    t     = t0;
    soln0 = interp1(t, soln, tref);
     
    % Find the initial condition at the starting point for the interventions
    geq = @(t,in) goveqs_scaleup(t, in, r, M0, M0, [2022 2023], i0, prm, sel0, agg0);
    [ta, solna] = ode15s(geq, [2022:tend1], init0, odeset('NonNegative',[1:i0.nstates]));
    initb = solna(end,:);
   
    % --- Next simulate with interventions
    r1 = r; p1 = p;
    p1.pu  = p.pu + (1- p.pu)*0.35; 
    p1.Dx(1) = 0.95;          % [0.95 0.95];  
   
  
age_gp = 3:5; %4;  % choose specific age group or age-groups
csfac = 1.2; % Choose any positive number to increase or decrease of care-seeking rate 
    r1.cs(age_gp)  = max(r.cs_1997(age_gp),r.cs(age_gp)*csfac);
    r1.cs2(age_gp) = max(r.cs2_1997(age_gp),r.cs2(age_gp)*csfac);
    r1.cs3(age_gp) = max(r.cs_1997(age_gp),r.cs(age_gp)*csfac);
    
    qq = 0.05;                                           % Preventive therapy among household contacts independent of hiv status
    r1.progression(age_gp,:)  = r.progression(age_gp,:)*(1-qq);    % Replace by this  --> p.PT_PLHIV = [1 1 (1-0.6)]
    r1.reactivation(age_gp,:) = r.reactivation(age_gp,:)*(1-qq);
    
    p.PT_PLHIV = [1 1 (1-0.6)];                           % PT among PLHIV reduces rate by 60%
    
    p1.MDR_rec = [0.5,0]; %0.7; %0.8;
    r1.Tx2 = 12/9;                             % Shorter Tx2 regimn (9 months)
    p1.cure2 = [0.7, 0]; %0.8; %0.9;
    r1.default(1) = r.default(1)*(1-0.05);     % reduction of default rate(pu) (by increasing Tx completion and reducing LTFU)     
 
    r1.ART_init = r.ART_init*(1+0.5);          % Increase of ART coverage
    
    % Reduction of relapse rate
    red_rps = 0; %0.1; % Proportion reduction of relapse rate
    r1.relapse = r.relapse.*(1 - red_rps);
    r1.vacc = [0 0 0 0 0];
    p1.VE = [0.7  0.7];
    
    M1 = make_model3(p1, r1, i0, s0, gps0,prm);
      
    geq = @(t,in) goveqs_scaleup(t, in, r, M0, M1, tend1 + [0  3], i0, prm, sel0, agg0);
    [tb, solnb] = ode15s(geq, [tend1 tend2], initb, opts);
  
    soln  = [solna; solnb(2:end,:)]; 
    t     = [ta;    tb(2:end)];
    soln8 = interp1(t, soln, tref); 
    
    % --- Next simulate with vaccination
    % Find vaccination starting point
    [tv, solnv] = ode15s(geq, [tend1 tend1b], initb, opts);
    initv = solnv(end,:);
   
    % Choose suitable rate of vaccination and vaccine efficacy
    r2 = r1; p2 = p1;
    p2.VE = [0.7  0.7];                    % Efficacy--> [infection prevention, disease prevention]
    r2.vacc = [0 0 0.3 0.3 0.3];               % Vaccination rate (chosen)
    M2 = make_model3(p2, r2, i0, s0, gps0, prm); % With vaccine
      
    geq = @(t,in) goveqs_scaleup(t, in,r, M1, M2, tend1b + [0  3], i0, prm, sel0, agg0); 
    [tc, solnc] = ode15s(geq, [tend1b tend2], initv, opts);
  
    soln  = [solna; solnv(2:end,:); solnc(2:end,:)];
    t     = [ta;    tv(2:end);      tc(2:end)];
     
   soln9 = interp1(t, soln, tref);
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
    % --- Bring them all together (baseline, interventions other than vaccine, interventions including vaccine)
   allmat = cat(3, soln0,soln8,soln9); 
   
    pop = sum(allmat(1:end-1,1:i0.nstates,1),2);  %2022:2035 (1:end -> 2022:2036)
    
    dallmat = diff(allmat,[],1);
    pop1=repmat(pop,[1,3]);
    
    inct(:,:)   = squeeze(dallmat(:,i0.aux.inc(1),:))./pop1*1e5;      % Total incidence
    inch1(:,:)  = squeeze(dallmat(:,i0.aux.inc(2),:))./pop1*1e5;      % HIV incidence
    mdr(:,:)    = squeeze(dallmat(:,i0.aux.inc(3),:))./pop1*1e5;      % MDR incidence
    morth0(:,:) = squeeze(dallmat(:,i0.aux.mort(1),:))./pop1*1e5;     % hiv-negative mortality
    morth1(:,:) = squeeze(dallmat(:,i0.aux.mort(2),:))./pop1*1e5;     % hiv-positive mortality
    noti(:,:)   = squeeze(sum(dallmat(:,i0.aux.noti,:),2))./pop1*1e5; % Total notification
    notimdr(:,:)= squeeze(dallmat(:,i0.aux.noti2,:))./pop1*1e5;       % MDR Treatment initiation
   
    artcovg(:,:) = squeeze(sum(allmat(:,s.hart,:),2)./sum(allmat(:,[s.h1,s.hart],:),2));
    
    
    %   prvt = squeeze(sum(allmat(:,s0.prevalent,:),2))*1e5;       % Prevalence
    prvty(:,:) = squeeze(sum(allmat(1:end-1,s0.prevalent,:),2))./pop1*1e5;                              %yearly prevalence
    prvt_mdry(:,:) = squeeze(sum(allmat(1:end-1,intersect(s0.prevalent,s0.mdr),:),2))./pop1*1e5;         %yearly mdr prevalence
    prvt_hivy(:,:) = squeeze(sum(allmat(1:end-1,intersect(s0.prevalent,[s0.h1,s0.hart]),:),2))./pop1*1e5; %yearly hiv prevalence
    ARTI(:,:) = squeeze(xs(xi.r_beta)*sum(allmat(1:end-1,intersect(s0.infectious,s.h0),:),2)./sum(allmat(2:end,1:size(d0,1),:),2));  % Yearly
   
    incty(:,:) = squeeze(diff(allmat(:,i0.aux.inc(1),:),[],1))./pop1*1e5;      %yearly all incidence
    inc_hivy(:,:) = squeeze(diff(allmat(:,i0.aux.inc(2),:),[],1))./pop1*1e5;   %yearly hiv-tb incidence
    inc_mdry(:,:) = squeeze(diff(allmat(:,i0.aux.inc(3),:),[],1))./pop1*1e5;   %yearly mdr incidence
    mrty(:,:)  = squeeze(diff(allmat(:,i0.aux.mort(1),:),[],1))./pop1*1e5;     %yearly hiv-negative TB mortality
    mrt_hivy(:,:)  = squeeze(diff(allmat(:,i0.aux.mort(2),:),[],1))./pop1*1e5; %yearly hiv-positive TB mortality
    notiy(:,:) = squeeze(sum(diff(allmat(:,i0.aux.noti,:),[],1),2))./pop1*1e5; %yearly notification 
    notimdry(:,:) = squeeze(diff(allmat(:,i0.aux.noti2,:),[],1))./pop1*1e5;   %yearly MDR Tx initiation
   
    LTBI_recent(:,:) = squeeze(sum(allmat(1:end-1,intersect(s0.Lf,s0.h0),:),2))./pop1*1e5;   %yearly LTBI (only hiv-ve) 
    LTBI_remote(:,:) = squeeze(sum(allmat(1:end-1,intersect(s0.Ls,s0.h0),:),2))./pop1*1e5;   %yearly LTBI (only hiv-ve)

    LTBI(:,:) = squeeze(sum(allmat(1:end-1,[s0.Lf,s0.Ls],:),2))./pop1*1e5;         %yearly total LTBI
   % TB_woTx(:,:,ii) = squeeze(sum(allmat(2:12:end,s.infectious,:),2));         %yearly Active TB cases without Tx 
   % TB_woTx(:,:,ii) = squeeze(sum(allmat(2:12:end,s.infectious,:),2));         %yearly Active TB cases without Tx 
   pop_vac(:,:) = squeeze(sum(allmat(1:end-1,intersect(1:i0.nstates,s0.v1),:),2));  % Vaccinated
   pop_elivac(:,:) = squeeze(sum(allmat(1:end-1,intersect(intersect(1:i0.nstates,[s0.v0,s0.v1]),[s0.a3,s0.a4,s0.a5]),:),2));  % Vaccinated

   Sus1(:,:) = squeeze(sum(allmat(1:end-1,intersect([s0.U,s0.Lf,s0.Ls, s0.Rlo, s0.Rhi, s0.R],s0.h0),:),2))./pop1*1e5; % Susceptiable population including U
   Sus2(:,:) = squeeze(sum(allmat(1:end-1,intersect([s0.Lf,s0.Ls, s0.Rlo, s0.Rhi, s0.R],s0.h0),:),2))./pop1*1e5;     % Susceptiable population excluding U
     
    

%tab.pop       = [data.pop00_22(end-3:end-1), 43326489, 43044540	42760880	42476294	42190115	41901694	41610116	41314544	41014863]; % pop_19_30;                                        %pop from 2019-2029
tab.prvty_pct = permute(prvty*1e5,[2,1,3]);       %yearly prevalence
tab.prvtmdry_pct = permute(prvt_mdry*1e5,[2,1,3]);%yearly mdr-TB-prevalence
tab.prvthivy_pct = permute(prvt_hivy*1e5,[2,1,3]);%yearly hiv-TB-prevalence
tab.ARTI = permute(ARTI*1e2,[2,1,3]);            % In percentage    

tab.incy_pct  = permute(incty*1e5,[2,1,3]);       %yearly incidence
tab.inchivy_pct  = permute(inc_hivy*1e5,[2,1,3]); %yearly hiv-TB incidence
tab.incmdry_pct  = permute(inc_mdry*1e5,[2,1,3]); %yearly mdr-incidence

tab.mrty_pct  = permute(mrty*1e5,[2,1,3]);        %yearly hiv-ve mortality
tab.mrthivy_pct  = permute(mrt_hivy*1e5,[2,1,3]); %yearly hiv-TB mortality

tab.LTBIrecent_pct = permute(LTBI_recent*1e5,[2,1,3]);  %yearly LTBI recent(fast)
tab.LTBIremote_pct = permute(LTBI_remote*1e5,[2,1,3]);  %yearly LTBI remote(slow)

tab.LTBI_pct = permute(LTBI*1e5,[2,1,3]);         %yearly LTBI remote(slow)
tab.population_pct = permute(pop*1e5,[2,1,3]);    

tab.noti_pct = permute(notiy*1e5,[2,1,3]);        % Yearly notification
tab.notimdry_pct = permute(notimdry*1e5,[2,1,3]); %yearly mdr Tx initiation

save res_forward; %with disruption   




%  Figure_final
 
figure; lw = 1.5;
subplot(2,2,1)
plot(2022:tend2-1,inct,'linewidth',lw); hold on; %inct 
ylabel('All Incidence')
plot(2022:tend2-1, (aux.inc2015*(1-0.9))*ones(size(2022:tend2-1)), '--k', 'LineWidth', lw);
xlim([2022 tend2-1])
subplot(2,2,2)
plot(2022:tend2-1,mdr,'linewidth',lw)
ylabel('MDR incidence')
xlim([2022 tend2-1])
subplot(2,2,3)
plot(2022:tend2-1,noti,'linewidth',lw)
ylabel('Notification')
xlim([2022 tend2-1])
subplot(2,2,4)
pl1 = plot(2022:tend2-1,notimdr,'linewidth',lw);
ylabel('MDR treatment initiation')
xlim([2022 tend2-1])
%legend(pl1,'Baseline','+PPM','+ Improved diagnostics, routine TB services','+ Upstream case-finding','+ case-finding among subclinical','+ Preventive therapy (risk group)','+ Upfront DST','+ Shorter duration of 2ndline Tx','+ Improved secondline Tx success','+ Vaccination','location','SouthEast'); %
legend(pl1,'Baseline','Interventions without vaccine','+ Vaccination','location','SouthEast'); %
 

figure;
subplot(1,2,1)
plot(2022:tend2-1,[pop,pop_elivac(:,3),pop_vac(:,3)],'linewidth',lw);  
legend('Total population','Eligible population(>10 year)','Vaccinated population')
ylabel('Population')
xlim([2022 tend2-1])

% Vaccine coverage
subplot(1,2,2)
plot(2022:tend2-1,[pop_vac(:,3)*100./pop,pop_vac(:,3)*100./pop_elivac(:,3)],'linewidth',lw)
legend('Among total population','Among eligible population(>10 year)')
ylabel('Percentage coverage')
xlim([2022 tend2-1])
