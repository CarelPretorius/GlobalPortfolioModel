function [Outputs_LS]=RunScenarioLS(ISO3, PlotFigures);

%prior to clearing all variables, save function inputs. May not be needed
%in Python.
ScnPARS{1}=ISO3;
ScnPARS{2}=PlotFigures;
save ScnPARS.mat ScnPARS

close all;%figures
clear all;%variables 

%Location of Dynamical model 
cd C:\work\GlobalModel\IND_Final2

load calibres1.mat xsto2 outsto2 prm ref sel agg gps gps1 gps2 lhd data i
%load Model_setup.mat prm ref sel agg gps gps1 gps2 lhd data i

%PARS{1}=xsto2;%country-specific
%PARS{2}=outsto2;%country-specific

PARS{1}=prm;
PARS{2}=ref;
PARS{3}=sel;
PARS{4}=agg;
PARS{5}=gps;
PARS{6}=gps1;
PARS{7}=gps2;
PARS{8}=lhd;
YearTGF=2010;
PARS{9}=YearTGF;


cd C:\work\GlobalModel\IND_Final2

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load ScnPARS.mat ScnPARS
ISO3=ScnPARS{1};
PlotFigures=ScnPARS{2};

PathToModel='C:\work\GlobalModel\IND_Final2';
PathToScenarioModel='C:\work\GlobalModel\IND_Final2';

xsto=xsto2; 
outsto=outsto2 ; 

ix0 = 3e4; nx = 15; dx = round((size(xsto,1)-ix0)/nx);
xs = xsto(ix0:dx:end,:,1);

%pct_xs= prctile(xs,[2.5,50,97.5])

inds = find(outsto==max(outsto));
xs = xsto(inds(1),:);

% pop2005_2022 = data.pop00_22(6:end);
% pop2000_2022 = data.pop00_22;

hist_final_year=2035;
x_final_year=2035;


%mk = round(size(xs,1)/25);
for ii = 1:size(xs,1)
    
    %if mod(ii,mk) == 0; fprintf('%0.5g ',ii/mk); end 
    %[out, aux] = obj(xs(ii,:));
    [out, aux] = get_LS2(xs(ii,:), PARS, PathToModel);
    
    sims(ii,:) = [aux.inc2000,aux.inc2022, aux.inc_h1, aux.noti, aux.noti_cu/10, aux.mort_H02000,aux.mort_H02022, aux.mort_H1, aux.ART_covg, aux.HIV_prev, aux.mdr2022, aux.mdriniTX];
    inct(:,:,ii) = diff(aux.soln(:,i.aux.inc),1)*1e5;  %2003:2019
      
    % Lives saved calculation
    incd(:,ii)  = aux.incd;   % Current
    incdb(:,ii) = aux.incdb;  % Null coverage from YearTGF/2005 
    incdc(:,ii) = aux.incdc;  % Constant coverage from YearTGF/2005 
    incdd(:,ii) = aux.incdd;  % Null coverage from 2000 
    incde(:,ii) = aux.incde;  % Constant coverage from 2000 
    incdf(:,ii) = aux.incdf;  % Null coverage from 2022 
    incdg(:,ii) = aux.incdg;  % Constant coverage from 2022 

    mor(:,ii)  = aux.mort;   % Current 1997 - 2022
    morb(:,ii) = aux.mortb;  % Null scenario from 2000
    morc(:,ii) = aux.mortc;  % Constant coverage at 2000
    mord(:,ii) = aux.mortd;  % Null coverage at YearTGF/2005
    more(:,ii) = aux.morte;  % Constant coverage at YearTGF/2005
    morf(:,ii) = aux.mortf;  % Null coverage from 2022 
    morg(:,ii) = aux.mortg;  % Constant coverage from 2022
    
end

incd_LS=[];
incd_LS{1}=incd;
incd_LS{2}=incdb;
incd_LS{3}=incdc;
incd_LS{4}=incdd;
incd_LS{5}=incde;
incd_LS{6}=incdf;
incd_LS{7}=incdg;

mor_LS=[];
mor_LS{1}=mor;
mor_LS{2}=morb;
mor_LS{3}=morc;
mor_LS{4}=mord;
mor_LS{5}=more;
mor_LS{6}=morf;
mor_LS{7}=morg;

Outputs_LS=[];
Outputs_LS{1}=incd_LS;
Outputs_LS{2}=mor_LS;

h=[];
Outputs_LS{3}=h;
if(PlotFigures==1)
    lw = 1.5;
    
    h=figure(1)
    subplot(2,1,1)
    hold on
        
    plot([1997:hist_final_year],incd,'k-','linewidth',lw)
    plot([2000:hist_final_year],incdb,'r:','linewidth',lw)
    plot([2000:hist_final_year],incdc,'r-','linewidth',lw)
    plot([YearTGF:hist_final_year],incdd,'b:','linewidth',lw)
    plot([YearTGF:hist_final_year],incde,'b-','linewidth',lw)
    plot([2022:1:2035],incdf,'g:','linewidth',lw)
    plot([2022:1:2035],incdg,'g-','linewidth',lw)
    
    title('TB incidence')
    ylabel('TB incidence per 100K')
    legend('Baseline','Null 2000','CC 2000','Null 2005','CC 2005', 'Null 2022','CC 2022');%,'location','NorthWest'); %
    xlim([2000 x_final_year])
    
    subplot(2,1,2)
    hold on
    plot([1997:hist_final_year],mor,'k-','linewidth',lw)
    plot([2000:hist_final_year],morb,'r:','linewidth',lw)
    plot([2000:hist_final_year],morc,'r-','linewidth',lw)
    plot([YearTGF:hist_final_year],mord,'b:','linewidth',lw)
    plot([YearTGF:hist_final_year],more,'b-','linewidth',lw)
    plot([2022:1:2035],morf,'g:','linewidth',lw)
    plot([2022:1:2035],morg,'g-','linewidth',lw)
    
    title('TB deaths - lives saved')
    ylabel('TB deaths per 100K')
    legend('Baseline','Null 2000','CC 2000','Null 2005','CC 2005','Null 2022','CC 2022');%,'location','NorthWest'); %
    xlim([2000 x_final_year])
    
    Outputs_LS{3}=h;
    %pause

    
end

end

